
import Action from './view/component/Action'

function App() {
  return (
    <div>
      <Action/>
    </div>
  );
}

export default App;
