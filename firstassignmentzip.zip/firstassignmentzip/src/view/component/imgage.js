import React, { Component } from 'react';
import '../assets/style.css';
class Images extends Component {
    constructor(props){
        super(props)
        this.state = {
          file: null,
          count:''
        }
    }
     handleChange=(e)=> {
        const imgfile= e.target.files[0];
        console.log(imgfile);
          if (!imgfile.name.match(/\.(jpg|jpeg|png|gif)$/)) {
            alert("select valid image jpg,png,gif" ,imgfile.type);
           return false;
          }
        this.setState({
          file:URL.createObjectURL(imgfile)
        }
        );
      }
     
    render() {
        return (
            <div>
               
                    <img src={this.state.file} className="img-width" />
                    <div className="inputimg">   
                    <input type="file" accept="image/x-png,image/gif,image/jpeg" onChange={this.handleChange}  className="inputtpefile"/>
                    <label className="lbl"> image upload</label>
                    </div>
                   
            </div>
        );
    } 
}

export default Images;