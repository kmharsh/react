import React, { Component } from 'react';
import '../assets/style.css';
class Videoupload extends Component {
  constructor(props) {
    super(props)
    this.state = {
      file: null
    }
  }
  handleChange = (e) => {
    const videofile= e.target.files[0];
    console.log(videofile.type);
      if (!videofile.name.match(/\.(mp4|MKV|MOV|AVI)$/)) {
        alert("select valid image mp4 , MKV MOV, AVI" ,videofile.type);
       return false;
      }
    this.setState({
      file:URL.createObjectURL(videofile)
    }
    );
  }
  render() {
    return (
      <div className="videsection">
          <video src={this.state.file} className="video-width" />
          <div className="video-tag">
          <input type="file" onChange={this.handleChange} accept="video/*" className="inputtpefile" />
          <label className="lbl"> video upload</label>
          </div>
      </div>
    );
  }
}

export default Videoupload;